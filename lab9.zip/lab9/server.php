<?php

echo json_encode($a);
json_decode($a, true);
    function avg($a) {
        $n = count($a);
        $sum = 0;
        for ($i = 0; $i < $n; $i++) {
            $sum += $a[$i];
        }
        $avg = $sum / $n;
        return $avg;
    }
    echo 'Average example 1+5='.'<br>';

    function median($a) {
        sort($a);
        $n = count($a);
      
        return  $a[$n / 2];
    }

    function standardDeviation($a) {
        $n = count($a);
        $average = avg($a);
        $variance = 0;
        foreach ($a as $x) {
            $variance += pow($x - $average, 2);
        }
        $stdDeviation = sqrt($variance / $n);
        return $stdDeviation;
    }

    function sum($x, $y) {
        $z = $x + $y;
        return $z;
    }
    //echo 'Sum example 1+5='. sum(1,5) .' 5+9='. sum(5,9) .' 8+6='. sum(8,6) .'<br>';  
?>